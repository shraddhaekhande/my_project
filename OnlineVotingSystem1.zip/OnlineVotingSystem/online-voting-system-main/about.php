<?php
include("header.html");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--Fonts CDN-->

    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    

    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: poppins;
        }
        img{
            border: 15px solid #555;
            margin-left: 10px;
            margin-right: 10px;
            margin-top: 10px;
            margin-bottom: 10px;
            border-radius: 10px;

            
           
        }
        img:hover{
            transform: scale(1.1,1.1);
            transition: 1.5s transform;
        }
        .container1{
            background-color: #a517ba;;
        }

     
        
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 style="text-align:center; margin-top:50px;"> About  </h1>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p>Voting is a method for a group, such as a meeting or an electorate, in order to make a collective decision or express an opinion usually following discussions, debates or election campaigns. Democracies elect holders of high office by voting. Residents of a place represented by an elected official are called "constituents", and those constituents who cast a ballot for their chosen candidate are called "voters". There are different systems for collecting votes, but while many of the systems used in decision-making can also be used as electoral systems, any which cater for proportional representation can only be used in elections.</p>
       
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 style="text-align:center; margin-top:50px;">ACES Ceremony </h1>
            </div>
            <div class="col-md-12">
                <p> The Computer Engineering Department, Investiture Ceremony of ZCOER on 28th march,
2022 for the elected members of “association of computer engineering students” of academic
session 2021-2022 was held with great pomp and dignity in a special ceremony at the CSMA
Hall. Total 15 students of ACES team were felicitated with badges and sashes by chief guests.
All the team took the oath for their position.
The election process was started from March 21, 2022 before this ceremony. Elections for
the post of captain and vice-captain were held on March 24 and for the post of vice-president and
treasurer on March 25.
The event and all election process was coordinated by Prof Pravin S. Patil under Guidance
of Prof. Aparna V.Mote. </p>
                
              
                </div>
           
            <div class="col-md-12">
                <div class="container1">
                <img src="img/img9.jpg" alt="" height="220px" width="320px">
                <img src="img/img7.jpg" alt=""height="220px" width="320px">
                <img src="img/img8.jpg" alt=""height="220px" width="320px">
                <img src="img/img4.jpg" alt=""height="220px" width="320px">
                <img src="img/img5.jpg" alt=""height="220px" width="320px">
                <img src="img/img6.jpg" alt=""height="220px" width="320px">
                </div>
            </div>

        </div>
    </div>

   

        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  
    <script src="js/jquery-3.2.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>    
    <script src="js/bootstrap.min.js"></script>  
</body>
</html>
<?php
    include("footer.html");
    ?>