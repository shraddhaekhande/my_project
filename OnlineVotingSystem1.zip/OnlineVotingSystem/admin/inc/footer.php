
    <div class="row bg-black text-center text-white">
        <div class="col-12 my-3">
            <p> &copy; Copyright 2022 - All Rights Reserved  <br />
                Developed by ShoaibLashari.com
            </p>
        </div>
    </div>

</div>

<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>